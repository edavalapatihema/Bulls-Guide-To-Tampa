﻿
using Newtonsoft.Json;

namespace BullsRideToTampa.Models
{
    public class BusinessType
    {
        public string TypeId { get; set; }
        public string TypeName { get; set; }
    }
}
