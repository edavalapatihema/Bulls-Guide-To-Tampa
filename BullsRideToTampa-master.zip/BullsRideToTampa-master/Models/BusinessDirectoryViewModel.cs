﻿namespace BullsRideToTampa.Models
{
    public class BusinessDirectoryViewModel
    {
    
        
        public List<Place> Places { get; set; }
        public List<Review> Reviews { get; set; }

    
}
}
